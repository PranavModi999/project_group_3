package com.example.firebaseupload


import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.lab3.Photo
import com.example.lab3.R
import com.firebase.ui.database.FirebaseRecyclerAdapter
import com.firebase.ui.database.FirebaseRecyclerOptions
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

class PhotoAdapter(
    options: FirebaseRecyclerOptions<Photo>,
) : FirebaseRecyclerAdapter<Photo, PhotoAdapter.PhotoViewHolder>(options) {


    override fun onBindViewHolder(holder: PhotoViewHolder, position: Int, model: Photo) {
        holder.listName.text = model.username

        val storageRef: StorageReference =
            FirebaseStorage.getInstance().getReferenceFromUrl(model.url!!)
        Glide.with(holder.listImage.context).load(storageRef).into(holder.listImage)

    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): PhotoAdapter.PhotoViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        Log.i("test77", "inside create")

        return PhotoViewHolder(inflater, parent)
    }

    class PhotoViewHolder(inflater: LayoutInflater, parent: ViewGroup) :
        RecyclerView.ViewHolder(inflater.inflate(R.layout.photo_list_item, parent, false)) {
        val listName: TextView = itemView.findViewById(R.id.listName)
        val listImage: ImageView = itemView.findViewById(R.id.listImage)
    }
}