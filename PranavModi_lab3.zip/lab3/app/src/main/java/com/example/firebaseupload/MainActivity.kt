package com.example.lab3

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.firebaseupload.PhotoAdapter
import com.firebase.ui.auth.AuthUI
import com.firebase.ui.auth.FirebaseAuthUIActivityResultContract
import com.firebase.ui.auth.data.model.FirebaseAuthUIAuthenticationResult
import com.firebase.ui.database.FirebaseRecyclerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import java.io.ByteArrayOutputStream
import java.util.*

class MainActivity : AppCompatActivity() {

    private var adapter: PhotoAdapter? = null

    private var cameraLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val uniqueID = UUID.randomUUID().toString()
                val photo = result.data?.extras?.get("data") as Bitmap
                uploadPhoto(photo, uniqueID)
                insertDB(uniqueID)


            }
        }

    override fun onStart() {
        super.onStart()
        adapter?.startListening()
    }

    private fun uploadPhoto(bmp: Bitmap, id: String) {

        val storageRef = FirebaseStorage.getInstance().getReference(id)
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos)
        val data = baos.toByteArray()
        val uploadTask = storageRef.putBytes(data)

        uploadTask.addOnFailureListener {
            Log.e("FBError", "Upload failed!")
        }.addOnSuccessListener {
            Log.i("Success", "Upload succeeded!")
        }
    }

    private fun insertDB(id: String) {

        val username = FirebaseAuth.getInstance().currentUser?.displayName
        val url = FirebaseStorage.getInstance().reference.toString() + id
        val p = Photo(url, username)
        FirebaseDatabase
            .getInstance()
            .reference
            .child("photos")
            .push()
            .setValue(p)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        createSignInIntent()
        val query = FirebaseDatabase.getInstance().reference.child("photos")

        val options = FirebaseRecyclerOptions
            .Builder<Photo>()
            .setQuery(query, Photo::class.java)
            .build()

        adapter = PhotoAdapter(options)

        val rView: RecyclerView = findViewById(R.id.photo_recycler)
        rView.layoutManager = LinearLayoutManager(this)
        rView.adapter = adapter
    }

    private fun loadUI() {

        val btnPhoto: Button = findViewById(R.id.btnPhoto)
        btnPhoto.setOnClickListener {

            val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            cameraLauncher.launch(takePictureIntent)

        }

    }

    private val signInLauncher = registerForActivityResult(FirebaseAuthUIActivityResultContract())
    { result ->
        this.onSignInResult(result)
    }

    private fun createSignInIntent() {
        val providers = arrayListOf(AuthUI.IdpConfig.EmailBuilder().build())

        val signInIntent = AuthUI.getInstance()
            .createSignInIntentBuilder()
            .setIsSmartLockEnabled(false)
            .setAvailableProviders(providers)
            .build()
        signInLauncher.launch(signInIntent)

    }

    private fun onSignInResult(result: FirebaseAuthUIAuthenticationResult) {
        if (result.resultCode == RESULT_OK) {
            // Successfully signed in
            loadUI()
            // ...
        } else {
            createSignInIntent()
        }
    }

}