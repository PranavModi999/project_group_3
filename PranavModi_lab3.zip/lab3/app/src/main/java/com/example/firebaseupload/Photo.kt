package com.example.lab3

data class Photo(var url: String? = "", val username: String? = "")

